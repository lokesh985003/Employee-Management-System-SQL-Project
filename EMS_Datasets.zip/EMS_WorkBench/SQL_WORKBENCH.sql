create database employee_management_system;

use employee_management_system;

-- 1.1 How many unique employees are currently in the system ?
select count(*) as totalemployees
from employee;

-- 1.2 departments with the highest number of employees
select jd.jobdept as jobdept, count(e.empid) as employeecount
from jobdepartment jd
left join employee e on jd.jobid = e.jobid
group by jd.jobdept
order by employeecount desc;

-- 1.3 average salary per department
select jd.jobdept as jobdept,
       round(avg(sb.amount),2) as avgsalary
from jobdepartment jd
join salary_bonus sb on jd.jobid = sb.jobid
group by jd.jobdept
order by avgsalary desc;

-- 1.4 top 5 highest-paid employees
select e.empid as empid, e.firstname as firstname, e.lastname as lastname, p.totalamount as totalamount
from payroll p
join employee e on p.empid = e.empid
order by p.totalamount desc
limit 5;

-- 1.5 total salary expenditure across company
select round(sum(totalamount),2) as totalexpenditure
from payroll;

-- 2.1 How many different job roles exist in each department?
select jobdept as jobdept, count(jobid) as totaljobroles
from jobdepartment
group by jobdept;

-- 2.2 What is the average salary range per department?
select jd.jobdept as department,
  coalesce(round(avg(sb.amount), 2), 0) as avg_salary
from jobdepartment jd
  left join salary_bonus sb
    on jd.jobid = sb.jobid
group by jd.jobdept
order by avg_salary desc;

-- 2.3 Which job roles offer the highest salary?
select jd.name as jobrole,
       jd.jobdept as department,
       sb.amount as salary
from jobdepartment jd
join salary_bonus sb on jd.jobid = sb.jobid
order by salary desc;

-- 2.4 departments with highest total salary allocation
select jd.jobdept as jobdept,
       sum(sb.amount) as totalsalaryallocation
from jobdepartment jd
join salary_bonus sb on jd.jobid = sb.jobid
group by jd.jobdept
order by totalsalaryallocation desc;	

-- 3.1 employees with at least one qualification
select count(distinct empid) as employeeswithqualifications
from qualification;

-- 3.2 positions requiring the most qualifications
select position,
       count(*) as totalqualifications
from qualification
group by position
order by totalqualifications desc;

-- 3.3 employees with the highest number of qualifications
select empid as empid,
       count(qualid) as numofqualifications
from qualification
group by empid
order by numofqualifications desc;

-- 4.1 year with the most employees taking leaves
select year(date) as leaveyear,
       count(distinct empid) as employeestakingleave
from leaves
group by year(date)
order by employeestakingleave desc;

-- 4.2 What is the average number of leave days taken by its employees per department?
select jd.jobdept as jobdept,count(l.leaveid) as totalleaves
from jobdepartment jd
join employee e on jd.jobid = e.jobid
join leaves l on e.empid = l.empid
group by jd.jobdept
order by totalleaves desc;

-- 4.3 employees who took the most leaves
select e.empid as empid, e.firstname as firstname, e.lastname as lastname,
       count(l.leaveid) as totalleaves
from employee e
join leaves l on e.empid = l.empid
group by e.empid, e.firstname, e.lastname
order by totalleaves desc;

-- 4.4 total leave days taken company-wide
select count(leaveid) as totalleavedays
from leaves;

-- 4.5 correlation between leave days & payroll
select p.totalamount as totalamount,
       count(l.leaveid) as totalleaves
from payroll p
left join leaves l on p.empid = l.empid
group by p.totalamount
order by totalleaves desc;

-- 5.1 total monthly payroll processed
select round(sum(p.totalamount),2) as totalpayrollprocessed
from payroll p;

-- 5.2 average bonus per department
select jd.jobdept as department,
       round(avg(sb.bonus), 2) as avgbonus
from jobdepartment jd
join salary_bonus sb on jd.jobid = sb.jobid
group by jd.jobdept
order by avgbonus desc;

-- 5.3 department receiving highest total bonuses
select jd.jobdept as department,
       sum(sb.bonus) as totalbonus
from jobdepartment jd
join salary_bonus sb on jd.jobid = sb.jobid
group by jd.jobdept
order by totalbonus desc
limit 1; 

-- 5.4 avg totalamount after leave deductions
select round(avg(p.totalamount), 2) as avgtotalamountafterdeductions
from payroll p;

